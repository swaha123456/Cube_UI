// DOM Elements
const hamburger = document.getElementById("hamburger");
const nav = document.getElementById("nav");
const mainImage = document.getElementById("mainImage");
const galleryDots = document.getElementById("galleryDots");
const thumbnails = document.querySelectorAll(".thumbnail");
const prevBtn = document.querySelector(".gallery-prev");
const nextBtn = document.querySelector(".gallery-next");
const addToCartBtn = document.getElementById("addToCartBtn");
const subscriptionRadios = document.querySelectorAll(
  'input[name="subscription"]',
);
const accordionItems = document.querySelectorAll(".accordion-item");

// Gallery Images
const galleryImages = [
  "/assets/Image_fx (14)-Photoroom 1.png",
  "/teal-blue-perfume-bottle.jpg",
  "/amber-orange-perfume-bottle.jpg",
  "/yellow-gold-perfume-bottle.jpg",
  "/colorful-flowers-bouquet.jpg",
  "/pink-rose-perfume.png",
  "/red-coral-perfume-bottle.jpg",
  "/sunflower-yellow-arrangement.jpg",
];

let currentImageIndex = 0;

// Hamburger Menu Toggle
hamburger.addEventListener("click", () => {
  hamburger.classList.toggle("active");
  nav.classList.toggle("active");
});

// Close menu when clicking a link
document.querySelectorAll(".nav-link").forEach((link) => {
  link.addEventListener("click", () => {
    hamburger.classList.remove("active");
    nav.classList.remove("active");
  });
});

// Gallery Functions
function updateGallery(index) {
  currentImageIndex = index;
  mainImage.src = galleryImages[index];

  // Update dots
  document.querySelectorAll(".dot").forEach((dot, i) => {
    dot.classList.toggle("active", i === index % 4);
  });

  // Update thumbnails
  thumbnails.forEach((thumb, i) => {
    thumb.classList.toggle("active", i === index);
  });
}

// Previous/Next Arrows
prevBtn.addEventListener("click", () => {
  const newIndex =
    (currentImageIndex - 1 + galleryImages.length) % galleryImages.length;
  updateGallery(newIndex);
});

nextBtn.addEventListener("click", () => {
  const newIndex = (currentImageIndex + 1) % galleryImages.length;
  updateGallery(newIndex);
});

// Thumbnail Clicks
thumbnails.forEach((thumb, index) => {
  thumb.addEventListener("click", () => {
    updateGallery(index);
  });
});

// Dot Clicks
document.querySelectorAll(".dot").forEach((dot, index) => {
  dot.addEventListener("click", () => {
    updateGallery(index);
  });
});

// Subscription Toggle
function toggleSubscriptionContent() {
  const singleContent = document.getElementById("singleContent");
  const doubleContent = document.getElementById("doubleContent");

  subscriptionRadios.forEach((radio) => {
    const content = radio.value === "single" ? singleContent : doubleContent;
    if (radio.checked) {
      content.classList.add("active");
    } else {
      content.classList.remove("active");
    }
  });

  updateCartLink();
}

subscriptionRadios.forEach((radio) => {
  radio.addEventListener("change", toggleSubscriptionContent);
});

// Initialize subscription content
toggleSubscriptionContent();

// Add to Cart Link Generator
const cartLinks = {
  "single-original": "https://example.com/cart/single-original",
  "single-lily": "https://example.com/cart/single-lily",
  "single-rose": "https://example.com/cart/single-rose",
  "double-original-original":
    "https://example.com/cart/double-original-original",
  "double-original-lily": "https://example.com/cart/double-original-lily",
  "double-original-rose": "https://example.com/cart/double-original-rose",
  "double-lily-original": "https://example.com/cart/double-lily-original",
  "double-lily-lily": "https://example.com/cart/double-lily-lily",
  "double-lily-rose": "https://example.com/cart/double-lily-rose",
  "double-rose-original": "https://example.com/cart/double-rose-original",
  "double-rose-lily": "https://example.com/cart/double-rose-lily",
  "double-rose-rose": "https://example.com/cart/double-rose-rose",
};

function updateCartLink() {
  const subscription = document.querySelector(
    'input[name="subscription"]:checked',
  ).value;
  let linkKey;

  if (subscription === "single") {
    const fragrance = document.querySelector(
      'input[name="fragrance-single"]:checked',
    ).value;
    linkKey = `single-${fragrance}`;
  } else {
    const fragrance1 = document.querySelector(
      'input[name="fragrance-double-1"]:checked',
    ).value;
    const fragrance2 = document.querySelector(
      'input[name="fragrance-double-2"]:checked',
    ).value;
    linkKey = `double-${fragrance1}-${fragrance2}`;
  }

  addToCartBtn.href = cartLinks[linkKey] || cartLinks["single-original"];
}

// Listen to all fragrance radio changes
document
  .querySelectorAll(
    'input[name="fragrance-single"], input[name="fragrance-double-1"], input[name="fragrance-double-2"]',
  )
  .forEach((radio) => {
    radio.addEventListener("change", updateCartLink);
  });

// Initialize cart link
updateCartLink();

// Accordion
accordionItems.forEach((item) => {
  const header = item.querySelector(".accordion-header");

  header.addEventListener("click", () => {
    const isActive = item.classList.contains("active");

    // Close all items
    accordionItems.forEach((i) => i.classList.remove("active"));

    // Open clicked item if it wasn't active
    if (!isActive) {
      item.classList.add("active");
    }
  });
});

// Stats Counter Animation
function animateCounters() {
  const statsSection = document.getElementById("statsSection");
  const counters = document.querySelectorAll(".stat-percent");
  let animated = false;

  function startCounting() {
    if (animated) return;

    const sectionTop = statsSection.getBoundingClientRect().top;
    const windowHeight = window.innerHeight;

    if (sectionTop < windowHeight * 0.8) {
      animated = true;

      counters.forEach((counter) => {
        const target = Number.parseInt(counter.getAttribute("data-target"));
        const duration = 2000;
        const step = target / (duration / 16);
        let current = 0;

        const updateCounter = () => {
          current += step;
          if (current < target) {
            counter.textContent = Math.floor(current) + "%";
            requestAnimationFrame(updateCounter);
          } else {
            counter.textContent = target + "%";
          }
        };

        updateCounter();
      });
    }
  }

  window.addEventListener("scroll", startCounting);
  startCounting(); // Check on load
}

// Initialize
document.addEventListener("DOMContentLoaded", () => {
  animateCounters();
});

// Smooth scroll for anchor links
document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
  anchor.addEventListener("click", function (e) {
    e.preventDefault();
    const target = document.querySelector(this.getAttribute("href"));
    if (target) {
      target.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    }
  });
});
